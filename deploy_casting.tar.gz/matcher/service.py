import logging
import datetime
from sqlalchemy import select
from database.session import async_session
from database.models import Casting, ActorProfile, Match

logger = logging.getLogger(__name__)

async def match_casting_with_actors(casting_id: int) -> None:
    logger.info(f"Triggered matcher for casting_id={casting_id}")

    async with async_session() as session:
        result = await session.execute(select(Casting).where(Casting.id == casting_id))
        casting = result.scalar_one_or_none()
        if not casting:
            logger.error(f"Casting id={casting_id} not found.")
            return

        import json
        criteria = json.loads(casting.criteria) if isinstance(casting.criteria, str) else (casting.criteria or {})

        c_genders       = criteria.get("genders", [])
        c_age_min       = criteria.get("age_min", 0)
        c_age_max       = criteria.get("age_max", 100)
        c_cities        = criteria.get("cities", [])
        c_project_types = criteria.get("project_types", [])
        c_fee           = criteria.get("fee", 0) or 0
        c_is_ams        = criteria.get("is_ams", False)

        # Base query — only actors with active subscription
        actors_stmt = select(ActorProfile).where(
            ActorProfile.subscription_end_date > datetime.datetime.now()
        )

        # Fee filter: only if casting specifies fee > 0
        if c_fee > 0:
            actors_stmt = actors_stmt.where(ActorProfile.min_fee <= c_fee)

        # Gender filter
        if c_genders:
            actors_stmt = actors_stmt.where(ActorProfile.gender.in_(c_genders))

        actors = (await session.execute(actors_stmt)).scalars().all()

        # "Другое" is a fallback — skip project type filter if it's the only type
        only_other = c_project_types == ["Другое"]

        matched_actors = []
        for actor in actors:
            # Age range must overlap
            if actor.playing_age_min > c_age_max or actor.playing_age_max < c_age_min:
                continue

            # City filter
            if c_cities:
                actor_cities = [c.strip() for c in (actor.city or "").split(",")]
                if "Все города" not in actor_cities:
                    if not any(city in actor_cities for city in c_cities) and "Все города" not in c_cities:
                        continue

            # Project type filter (skip if casting is only "Другое")
            if c_project_types and not only_other:
                proj_map = {
                    "Кино и сериалы": actor.proj_cinema,
                    "Реклама": actor.proj_ads,
                    "Некоммерч": actor.proj_nonprofit,
                    "Международные": actor.proj_international,
                    "Клипы": actor.proj_clips,
                    "Театр": actor.proj_theater,
                    "Озвучка": actor.proj_dubbing,
                    "Другое": actor.proj_other,
                }
                has_match = any(
                    proj_map.get(p, False)
                    for p in c_project_types
                    if p in proj_map
                )
                # Partial match: check by keywords
                if not has_match:
                    for p in c_project_types:
                        for key, val in proj_map.items():
                            if key in p or p in key:
                                if val:
                                    has_match = True
                                    break
                if not has_match:
                    continue

            # AMS option
            if c_is_ams and actor.opt_exclude_ams:
                continue

            matched_actors.append(actor)

        if not matched_actors:
            logger.info(f"No matching actors for casting_id={casting_id}")
            return

        new_matches = []
        for actor in matched_actors:
            match = Match(actor_id=actor.user_id, casting_id=casting_id, status="pending")
            new_matches.append(match)
        session.add_all(new_matches)
        await session.commit()
        logger.info(f"Created {len(new_matches)} matches for casting_id={casting_id}")

        from .notifier import notify_matched_actors
        await notify_matched_actors(casting_id)
